```python
import pandas as pd
import numpy as np
from IPython.display import display
import random
from sklearn.model_selection import LeaveOneOut
from sklearn.linear_model import LinearRegression, LogisticRegression
import random
from sklearn.metrics import recall_score, confusion_matrix, accuracy_score
from sklearn.model_selection import train_test_split
from IPython.display import display
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
```


```python
tagsFile = "tags"
recipesFile = "recipes"
nutritionsFile = "nutritions"
ingredientsFile = "ingredients"

tagsdf = pd.read_csv(f"/data/foodboost/{tagsFile}.csv", index_col=0)
recipesdf = pd.read_csv(f"/data/foodboost/{recipesFile}.csv", index_col=0)
```


```python
def recepten_bij_tag(tag):
    a = tagsdf.loc[tagsdf['tag'] == tag].recipe.to_list()
    return a
def tags_bij_recept(gerecht):
    b = tagsdf.loc[tagsdf['recipe'] == gerecht].tag.unique()
    return b
```


```python
for i in range(10):
    print(random.choices(tagsdf["tag"].to_list()))
```

    ['bijgerecht']
    ['hoofdgerecht']
    ['kinderrecepten']
    ['engels']
    ['lactosevrij']
    ['oven']
    ['wat eten we vandaag']
    ['hoofdgerecht']
    ['budget']
    ['italiaans']



```python
def User_Favo_Random_Tags(randomTag = random.choices(tagsdf["tag"].to_list(), k=1), K=10):
    while len(recepten_bij_tag(randomTag[0])) < K:
        randomTag = random.choices(tagsdf["tag"].to_list(), k=1)
    
    #Lekker
    print('lengte recipes lijst lekker: ' + str(len(recepten_bij_tag(randomTag[0]))))
    RandomReceptenVoorTag = random.choices(recepten_bij_tag(randomTag[0]), k= K)
    Train_Favorieten, Test_Favorieten = RandomReceptenVoorTag[:int(K*0.8)], RandomReceptenVoorTag[int(K*0.8):]
    
    UserList_Tags = [tags_bij_recept(x) for x in Train_Favorieten]
    
    #Niet lekker
    #Niet lekker OFWEL RANDOM DIE NIET MET FAVOTAG TE MAKEN HEBBEN
    #Niet_Favo_df = [x for x in recipesdf["title"] if x not in np.array(recepten_bij_tag(randomTag[0]))]
    Niet_Favo_df = list(set(recipesdf["title"].to_list()).difference(recepten_bij_tag(randomTag[0])))
    Niet_Lekker_Recepten_Voor_Tag = random.choices(Niet_Favo_df, k= K)
    Train_Favorieten_Niet_Lekker, Test_Favorieten_Niet_Lekker = Niet_Lekker_Recepten_Voor_Tag[:int(K*0.8)], Niet_Lekker_Recepten_Voor_Tag[int(K*0.8):]
    
    Train_Favorieten_Niet_Lekker_Tags = [tags_bij_recept(x) for x in Train_Favorieten_Niet_Lekker]
    Test_Favorieten_Niet_Lekker_Tags = [tags_bij_recept(x) for x in Test_Favorieten_Niet_Lekker]
    #RandomRecepten = random.choices(recipesdf["title"].to_list(), k=int(K*0.8))
    
    #Random_Tags = [tags_bij_recept(x) for x in RandomRecepten]


    return Train_Favorieten, UserList_Tags, Train_Favorieten_Niet_Lekker_Tags, Train_Favorieten_Niet_Lekker, randomTag, K, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags
```


```python
NumberOfUsers = 500
NumberOfRecipes = 20
UsersList = []
for i in range(NumberOfUsers):
    UserList, UserList_Tags, randomTags, randomRecipes, Usertag, K, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags = User_Favo_Random_Tags(randomTag = random.choices(tagsdf["tag"].to_list(), k=1), K=NumberOfRecipes)
    User = np.array([UserList, UserList_Tags, randomTags, randomRecipes, Usertag, K, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags])
    UsersList.append(User)

ListSize = len(UsersList)
TrainUsers, ValidateUsers, TestUsers = UsersList[:int(ListSize*0.6)], UsersList[int(ListSize*0.6): int(ListSize*0.8)], UsersList[int(ListSize*0.8):]
```

    lengte recipes lijst lekker: 423
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 505


    /tmp/ipykernel_14444/1179687906.py:6: VisibleDeprecationWarning: Creating an ndarray from ragged nested sequences (which is a list-or-tuple of lists-or-tuples-or ndarrays with different lengths or shapes) is deprecated. If you meant to do this, you must specify 'dtype=object' when creating the ndarray.
      User = np.array([UserList, UserList_Tags, randomTags, randomRecipes, Usertag, K, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags])


    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 114
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 216
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 482
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 627
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 83
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 557
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 380
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 225
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 147
    lengte recipes lijst lekker: 110
    lengte recipes lijst lekker: 159
    lengte recipes lijst lekker: 93
    lengte recipes lijst lekker: 348
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 323
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 60
    lengte recipes lijst lekker: 346
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 482
    lengte recipes lijst lekker: 283
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 398
    lengte recipes lijst lekker: 352
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 379
    lengte recipes lijst lekker: 435
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 398
    lengte recipes lijst lekker: 107
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 323
    lengte recipes lijst lekker: 39
    lengte recipes lijst lekker: 822
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 191
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 505
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 482
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 124
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 435
    lengte recipes lijst lekker: 206
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 557
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 627
    lengte recipes lijst lekker: 206
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 216
    lengte recipes lijst lekker: 346
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 347
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 557
    lengte recipes lijst lekker: 110
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 627
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 822
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 557
    lengte recipes lijst lekker: 86
    lengte recipes lijst lekker: 239
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 206
    lengte recipes lijst lekker: 283
    lengte recipes lijst lekker: 627
    lengte recipes lijst lekker: 347
    lengte recipes lijst lekker: 323
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 505
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 380
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 375
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 505
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 398
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 423
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 423
    lengte recipes lijst lekker: 627
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 375
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 86
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 380
    lengte recipes lijst lekker: 347
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 323
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 144
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 505
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 243
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 216
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 505
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 323
    lengte recipes lijst lekker: 248
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 104
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 398
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 423
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 379
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 482
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 225
    lengte recipes lijst lekker: 199
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 225
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 124
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 86
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 60
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 627
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 822
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 283
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 822
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 423
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 346
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 347
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 375
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 131
    lengte recipes lijst lekker: 380
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 60
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 221
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 191
    lengte recipes lijst lekker: 323
    lengte recipes lijst lekker: 348
    lengte recipes lijst lekker: 86
    lengte recipes lijst lekker: 557
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 225
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 175
    lengte recipes lijst lekker: 437
    lengte recipes lijst lekker: 199
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 216
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 346
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 304
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 822
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 107
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 398
    lengte recipes lijst lekker: 352
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 822
    lengte recipes lijst lekker: 1071
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 379
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 557
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 347
    lengte recipes lijst lekker: 435
    lengte recipes lijst lekker: 248
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 848
    lengte recipes lijst lekker: 822
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 435
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 348
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 500
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 131
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 243
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 1250
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1118
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 717
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 435
    lengte recipes lijst lekker: 789
    lengte recipes lijst lekker: 827
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 649
    lengte recipes lijst lekker: 94
    lengte recipes lijst lekker: 323
    lengte recipes lijst lekker: 283
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 283
    lengte recipes lijst lekker: 573
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 239
    lengte recipes lijst lekker: 239
    lengte recipes lijst lekker: 1923
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1588
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 2768
    lengte recipes lijst lekker: 620
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 110
    lengte recipes lijst lekker: 283
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 347
    lengte recipes lijst lekker: 375
    lengte recipes lijst lekker: 1277
    lengte recipes lijst lekker: 1435
    lengte recipes lijst lekker: 4595
    lengte recipes lijst lekker: 159
    lengte recipes lijst lekker: 762
    lengte recipes lijst lekker: 1679
    lengte recipes lijst lekker: 1495
    lengte recipes lijst lekker: 2542
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 1291
    lengte recipes lijst lekker: 216
    lengte recipes lijst lekker: 573



```python
list_of_tags = tagsdf['tag'].unique().tolist()
```


```python
def fillInMatrix(matrix, column, index_counter, doDoubleRows, isY, columnPrefix = ""):
    size = len(column)
    if(type(column) == str):
        size = 1
    for i in range(size):
        matrix.loc[index_counter, columnPrefix + column[i]] = 1
        if(doDoubleRows):
            if(isY):
                matrix.loc[index_counter+1, columnPrefix + column[i]] = 0
            else:
                matrix.loc[index_counter+1, columnPrefix + column[i]] = 1
```


```python
#TRAIN_Matrix
def generateTrainMatrix(UserList, randomTags, randomRecipes):
    
    matrix = pd.DataFrame(columns = list_of_tags)
    
    for i in range(len(UserList*2)):
        matrix.loc[matrix.shape[0]] = 0
    
    columnPrefix = "2-"
    matrix2 = matrix.copy()
    matrix2.columns = [columnPrefix + columnName for columnName in matrix2.columns]
    
    X = np.array(UserList)
    loo = LeaveOneOut()
    index_counter = 0

    for train_index, test_index in loo.split(X):
        X_train, X_test = X[train_index], X[test_index]

        randomTags0 = randomTags.pop(0)
        randomgerecht0 = randomRecipes.pop(0)

        X_train_tags_unique = np.unique(np.concatenate([tags_bij_recept(x) for x in X_train]))
        X_test_tags_unique = np.unique(np.concatenate([tags_bij_recept(x) for x in X_test]))

        #----- Matrix met train vullen
        fillInMatrix(matrix, X_train_tags_unique, index_counter, True, False)
        
        #Rij 1
        fillInMatrix(matrix2, X_test_tags_unique, index_counter, False, False, columnPrefix = columnPrefix)
        #print(matrix2)
        
        #Rij 2
        fillInMatrix(matrix2, randomTags0, index_counter+1, False, False, columnPrefix = columnPrefix)
        
        #Put the value for the random tag as 1 and put y at 0, because it should be false
        fillInMatrix(matrix2, 'y', index_counter, True, True)
        
        #Show which random tag is taken and the one out
        matrix2.loc[index_counter+1, 'Randomgerecht'] = str(randomgerecht0)
        matrix2.loc[index_counter, 'one out'] = X_test
        matrix2.loc[index_counter+1, 'one out'] = X_test
        
        index_counter += 2
    return pd.concat([matrix, matrix2], axis=1)
```


```python
#TEST_Matrix
def generateTestMatrix(UserList, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags):
    matrix1 = pd.DataFrame(columns = list_of_tags)
    Gerechten = np.array(UserList)
    Test_Gerechten = np.array(Test_Favorieten)
    
    for i in range(len(Test_Gerechten) + len(Test_Favorieten_Niet_Lekker_Tags)):
        matrix1.loc[matrix1.shape[0]] = 0
    
    matrix2 = matrix1.copy()
    columnPrefix = "2-"
    matrix2.columns = [columnPrefix + columnName for columnName in matrix2.columns]
    
    #-----
    for index_counter in range(len(Test_Gerechten)):
        
        Gerecht_Tags = np.unique(np.concatenate([tags_bij_recept(x) for x in Gerechten]))
        Test_Gerecht_Tags = tags_bij_recept(Test_Gerechten[index_counter])

        #----- Matrix1 met Userlist (1-8) invullen
        fillInMatrix(matrix1, Gerecht_Tags, index_counter, False, False)

        #----- Matrix2 met Test_Favorieten (9-10) vullen
        fillInMatrix(matrix2, Test_Gerecht_Tags, index_counter, False, False, columnPrefix = columnPrefix)
    
    for p in range(len(Test_Gerechten), len(Test_Gerechten) + len(Test_Favorieten_Niet_Lekker_Tags)):
        #----- Matrix1 met Userlist (1-8) invullen
        fillInMatrix(matrix1, Gerecht_Tags, p, False, False)
        
        fillInMatrix(matrix2, Test_Favorieten_Niet_Lekker_Tags, p, False, False, columnPrefix = columnPrefix)
    return pd.concat([matrix1, matrix2], axis=1)
```


```python
#--Dubbele Matrix Compleet
def testTrainMatrix():
    UserList, UserList_Tags, randomTags, randomRecipes, Usertag, K, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags = User_Favo_Random_Tags(K=NumberOfRecipes)
    VolledigeMatrix = generateTrainMatrix(UserList, randomTags, randomRecipes)
    return VolledigeMatrix
```


```python
testTrainMatrix()
```

    lengte recipes lijst lekker: 789





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>hollands</th>
      <th>gebak</th>
      <th>sinterklaas</th>
      <th>sinterklaasavond</th>
      <th>oven</th>
      <th>vooraf te maken</th>
      <th>lactosevrij</th>
      <th>thais</th>
      <th>aziatisch</th>
      <th>curry</th>
      <th>...</th>
      <th>2-valentijnsdag</th>
      <th>2-zuid-afrikaans</th>
      <th>2-koreaans</th>
      <th>2-kidsfavoriet</th>
      <th>2-diner</th>
      <th>2-lente</th>
      <th>2-jamie oliver</th>
      <th>y</th>
      <th>Randomgerecht</th>
      <th>one out</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Olijvenbrood met truffelolie en parmezaan ]</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Bbq gegrilde avocado met salsa en zwarte bonen</td>
      <td>[Olijvenbrood met truffelolie en parmezaan ]</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Zomerse pastabowl]</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Kleurrijke salade met broccolirijst en feta</td>
      <td>[Zomerse pastabowl]</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Babybietjes met burrata en pistachenoten ]</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Salade met penne rigate, peer en pancetta</td>
      <td>[Babybietjes met burrata en pistachenoten ]</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Linzen met ovengroenten]</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Fudgewafels met vanille-ijs</td>
      <td>[Linzen met ovengroenten]</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Börek met spinazie en feta]</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Gegrilde zalm met wortelsalade &amp;amp; bieslookk...</td>
      <td>[Börek met spinazie en feta]</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Kaasfondue met broccoli &amp;amp; brood]</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Croissant gevuld met avocado &amp;amp; eitjesalade</td>
      <td>[Kaasfondue met broccoli &amp;amp; brood]</td>
    </tr>
    <tr>
      <th>12</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Gegratineerde orzo met champignons en broccol...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Snelle pasta met artisjok, romige ricotta en spek</td>
      <td>[Gegratineerde orzo met champignons en broccol...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Zoeteaardappelfriet met kaasdip]</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Boerenkool met worst en spekjes</td>
      <td>[Zoeteaardappelfriet met kaasdip]</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Kaasplanktaart]</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Grapefruitgranita</td>
      <td>[Kaasplanktaart]</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Volkorennacho's met tomatensalsa en 30+ kaas]</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Speltpita met gegrilde kip en rodecoleslaw</td>
      <td>[Volkorennacho's met tomatensalsa en 30+ kaas]</td>
    </tr>
    <tr>
      <th>20</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Gevulde paprika met bonen, pompoen en amandel...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Penne arrabbiata met aubergine</td>
      <td>[Gevulde paprika met bonen, pompoen en amandel...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Aspergeragout in een pasteibakje]</td>
    </tr>
    <tr>
      <th>23</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Knolselderij met appel</td>
      <td>[Aspergeragout in een pasteibakje]</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Pasta pesto]</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Vegan pokébowl met watermeloen en rode rijst</td>
      <td>[Pasta pesto]</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Geroosterde groenten en ricotta uit de oven]</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Marshmallowkoekjes met chocolade en hagelpret</td>
      <td>[Geroosterde groenten en ricotta uit de oven]</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Boerenkoolstamppot met feta, rode ui en hazel...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Asperges met Parmezaanse kaas</td>
      <td>[Boerenkoolstamppot met feta, rode ui en hazel...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Tex-mexsalade met ovengeroosterde zoete aarda...</td>
    </tr>
    <tr>
      <th>31</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Draadjesvlees met Aziatische kruiden</td>
      <td>[Tex-mexsalade met ovengeroosterde zoete aarda...</td>
    </tr>
  </tbody>
</table>
<p>32 rows × 239 columns</p>
</div>




```python
def createTrainMatrix():
    Matrix = pd.DataFrame()
    for User in TrainUsers:
        UserList, randomTags, randomRecipes = User[0], User[2], User[3]
        TrainMatrix = generateTrainMatrix(UserList, randomTags, randomRecipes)
        Matrix = pd.concat([Matrix, TrainMatrix], axis=0, ignore_index=True)
    
    return Matrix
```


```python
def createValidateMatrix():
    Matrix = pd.DataFrame()
    y_validate = []
    for User in ValidateUsers:
        UserList, randomTags, randomRecipes, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags = User[0], User[2], User[3], User[6], User[7]
        TestMatrix = generateTestMatrix(UserList, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags)
        Matrix = pd.concat([Matrix, TestMatrix], axis=0, ignore_index=True)
        
        for p in Test_Favorieten:
            y_validate.append(1)
        for t in Test_Favorieten_Niet_Lekker_Tags:
            y_validate.append(0)
    return Matrix, y_validate
```


```python
def createTestMatrix():
    Matrix = pd.DataFrame()
    y_test = []
    for User in TestUsers:
        UserList, randomTags, randomRecipes, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags = User[0], User[2], User[3], User[6], User[7]
        TestMatrix = generateTestMatrix(UserList, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags)
        Matrix = pd.concat([Matrix, TestMatrix], axis=0, ignore_index=True)
        
        for p in Test_Favorieten:
            y_test.append(1)
        for t in Test_Favorieten_Niet_Lekker_Tags:
            y_test.append(0)
    return Matrix, y_test
```


```python
# for i in range(NumberOfUsers):
#     UserList, UserList_Tags, randomTags, randomRecipes, Usertag, K, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags = User_Favo_Random_Tags(randomTag = random.choices(tagsdf["tag"].to_list(), k=1), randomTagNietLekker = random.choices(tagsdf["tag"].to_list(), k=1), K=NumberOfRecipes)
#     TrainMatrix = generateTrainMatrix(UserList, randomTags, randomRecipes)
#     TestMatrix = generateTestMatrix(UserList, Test_Favorieten, Test_Favorieten_Niet_Lekker_Tags)
#     TotalTrainMatrix = pd.concat([TotalTrainMatrix, TrainMatrix], axis=0, ignore_index=True)
#     TotalTestMatrix = pd.concat([TotalTestMatrix, TestMatrix], axis=0, ignore_index=True)
#     for p in Test_Favorieten:
#         y_test.append(1)
#     for t in Test_Favorieten_Niet_Lekker_Tags:
#         y_test.append(0)
```


```python
TotalTrainMatrix = createTrainMatrix()
TotalValidateMatrix, y_validate = createValidateMatrix()
TotalTestMatrix, y_test = createTestMatrix()
```


```python
TotalTrainMatrix
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>hollands</th>
      <th>gebak</th>
      <th>sinterklaas</th>
      <th>sinterklaasavond</th>
      <th>oven</th>
      <th>vooraf te maken</th>
      <th>lactosevrij</th>
      <th>thais</th>
      <th>aziatisch</th>
      <th>curry</th>
      <th>...</th>
      <th>2-valentijnsdag</th>
      <th>2-zuid-afrikaans</th>
      <th>2-koreaans</th>
      <th>2-kidsfavoriet</th>
      <th>2-diner</th>
      <th>2-lente</th>
      <th>2-jamie oliver</th>
      <th>y</th>
      <th>Randomgerecht</th>
      <th>one out</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Ricottapannenkoekjes met honingboter &amp;amp; pr...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Botercrème (voor macarons)</td>
      <td>[Ricottapannenkoekjes met honingboter &amp;amp; pr...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Yoghurt met tuttifrutti en blauwe bessen]</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Eendenravioli met zachte eidooier en truffelsaus</td>
      <td>[Yoghurt met tuttifrutti en blauwe bessen]</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Yoghurtsmoothie met havermout, banaan en aard...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9595</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Groene kool met kikkererwten</td>
      <td>[Dukkah van Nadia en Merijn]</td>
    </tr>
    <tr>
      <th>9596</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Guacamole basisrecept]</td>
    </tr>
    <tr>
      <th>9597</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Filetlapjes met parmaham en salie</td>
      <td>[Guacamole basisrecept]</td>
    </tr>
    <tr>
      <th>9598</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>[Broccolistronk-pickles]</td>
    </tr>
    <tr>
      <th>9599</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Appelmoes-ontbijtcake met havermout</td>
      <td>[Broccolistronk-pickles]</td>
    </tr>
  </tbody>
</table>
<p>9600 rows × 239 columns</p>
</div>




```python
#--Dubbele Matrix
X_train = TotalTrainMatrix.drop(['y', 'Randomgerecht', 'one out'], axis=1)
y_train = TotalTrainMatrix['y'].to_list()
```


```python
TotalValidateMatrix_Values = TotalValidateMatrix.loc[:, (TotalValidateMatrix != 0).any(axis=0)]
#TotalValidateMatrix_Values
TotalValidateMatrix
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>hollands</th>
      <th>gebak</th>
      <th>sinterklaas</th>
      <th>sinterklaasavond</th>
      <th>oven</th>
      <th>vooraf te maken</th>
      <th>lactosevrij</th>
      <th>thais</th>
      <th>aziatisch</th>
      <th>curry</th>
      <th>...</th>
      <th>2-mealprep</th>
      <th>2-slowcooker</th>
      <th>2-oost-europees</th>
      <th>2-valentijnsdag</th>
      <th>2-zuid-afrikaans</th>
      <th>2-koreaans</th>
      <th>2-kidsfavoriet</th>
      <th>2-diner</th>
      <th>2-lente</th>
      <th>2-jamie oliver</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>795</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>796</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>797</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>798</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>799</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>800 rows × 236 columns</p>
</div>




```python
y_train
```




    [1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     1.0,
     0.0,
     ...]




```python
AmountOfRows = X_train[X_train.columns[0]].count()
print(AmountOfRows)
```

    9600



```python
def RFC():
    model_rfc = RandomForestClassifier(min_samples_split=16, min_samples_leaf=4, min_weight_fraction_leaf=0.05)
    model_rfc.fit(X_train, y_train)
    y_pred = model_rfc.predict(TotalValidateMatrix)
    print(recall_score(y_validate, y_pred))
    print(confusion_matrix(y_true = y_validate, y_pred = y_pred))
    print(accuracy_score(y_validate, y_pred))
```


```python
RFC()
```

    0.6425
    [[ 60 340]
     [143 257]]
    0.39625



```python
def testClassifiers():
    #---Modellen
    model_lr = LogisticRegression(max_iter=AmountOfRows+100)
    model_knn = KNeighborsClassifier()
    model_svm = SVC()
    model_rfc = RandomForestClassifier()
    
    parameters_lr = {'C': np.logspace(-5, 8, 15)}
    parameters_knn = {'n_neighbors': list(range(1, 10)),
                     'leaf_size' : list(range(1, 10)), 
                      'p':[1,2]}
    parameters_svm = {'C': [0.1, 1, 10, 100],  
                    'gamma': [1, 0.1, 0.01, 0.001, 0.0001], 
                    'gamma':['scale', 'auto']}
                    #'kernel': ['linear']}
    parameters_rfc = {'min_samples_split': [0,5,10,20],
                      'min_samples_leaf': [2,4,6,8,10],
                      'min_weight_fraction_leaf': [0.01, 0.05, 0.1]}
    
    #---Logistic Regression
    print("\nLogistic Regression")
    Grid_lr = GridSearchCV(model_lr, parameters_lr, cv=5)
    Grid_lr.fit(X_train, y_train)

    y_pred = Grid_lr.predict(TotalValidateMatrix)

    print("y_pred: ", y_pred)
    print("Tuned Logistic Regression Parameters: {}".format(Grid_lr.best_params_)) 
    print("Best score is {}".format(Grid_lr.best_score_))
    print("Confusion Matrix: ", confusion_matrix(y_true = y_validate, y_pred = y_pred))
    #print("Classification Report: ", classification_report(y_validate, y_pred))
    print("Accuracy Score: ", accuracy_score(y_validate, y_pred))
    print("Score: ", Grid_lr.score(TotalValidateMatrix, y_validate))

#---K_NearestNeighbors
    print("\nK_NearestNeighbors")
    Grid_knn = GridSearchCV(model_knn, parameters_knn, cv=5)
    Grid_knn.fit(X_train, y_train)

    y_pred = Grid_knn.predict(TotalValidateMatrix)

    print("y_pred: ", y_pred)
    print("Tuned K_NearestNeighbors Parameters: {}".format(Grid_knn.best_params_)) 
    print("Best score is {}".format(Grid_knn.best_score_))
    print("Confusion Matrix: ", confusion_matrix(y_true = y_validate, y_pred = y_pred))
    print("Accuracy Score: ", accuracy_score(y_validate, y_pred))
    print("Score: ", Grid_knn.score(TotalValidateMatrix, y_validate))

#---SVC
    print("\nSVM")
    Grid_svm = GridSearchCV(model_svm, parameters_svm, cv=5)
    Grid_svm.fit(X_train, y_train)

    y_pred = Grid_svm.predict(TotalValidateMatrix)

    print("y_pred: ", y_pred)
    print("Tuned SVM Parameters: {}".format(Grid_svm.best_params_)) 
    print("Best score is {}".format(Grid_svm.best_score_))
    print("Confusion Matrix: ", confusion_matrix(y_true = y_validate, y_pred = y_pred))
    print("Accuracy Score: ", accuracy_score(y_validate, y_pred))
    print("Score: ", Grid_svm.score(TotalValidateMatrix, y_validate))
    
#---RFC
    print("\nRFC")
    Grid_rfc = GridSearchCV(model_rfc, parameters_rfc, cv=5)
    Grid_rfc.fit(X_train, y_train)

    y_pred = Grid_rfc.predict(TotalValidateMatrix)

    print("y_pred: ", y_pred)
    print("Tuned RFC Parameters: {}".format(Grid_rfc.best_params_)) 
    print("Best score is {}".format(Grid_rfc.best_score_))
    print("Confusion Matrix: ", confusion_matrix(y_true = y_validate, y_pred = y_pred))
    print("Accuracy Score: ", accuracy_score(y_validate, y_pred))
    print("Score: ", Grid_rfc.score(TotalValidateMatrix, y_validate))

    print("====================================================================")
```


```python
testClassifiers()
```

    
    Logistic Regression
    y_pred:  [1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1.
     0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1.
     1. 0. 1. 0. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1.
     0. 0. 1. 0. 1. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1.
     0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1.
     1. 1. 0. 0. 1. 1. 1. 1. 0. 1. 1. 0. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1.
     0. 0. 1. 0. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1.
     0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1.
     1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1.
     1. 0. 0. 0. 1. 1. 1. 1. 0. 1. 0. 0. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1.
     0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1.
     0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1.
     0. 1. 1. 0. 1. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1.
     1. 1. 0. 0. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1.
     1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 0. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1.
     1. 1. 0. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1.
     0. 1. 0. 1. 1. 1. 1. 1. 0. 1. 0. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1.
     0. 0. 1. 0. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 0. 1. 1. 1. 1.
     0. 1. 0. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1.
     0. 1. 0. 0. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1.
     0. 1. 0. 0. 1. 1. 1. 1. 0. 1. 0. 0. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1.
     1. 1. 0. 0. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1.
     0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1.
     0. 1. 1. 0. 1. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1.
     1. 0. 0. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1.
     1. 0. 0. 1. 1. 1. 1. 1.]
    Tuned Logistic Regression Parameters: {'C': 0.05179474679231213}
    Best score is 0.5622916666666666
    Confusion Matrix:  [[  0 400]
     [186 214]]
    Accuracy Score:  0.2675
    Score:  0.2675
    
    K_NearestNeighbors
    y_pred:  [1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 0. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 0. 1. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0. 0. 0. 0.
     1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 0. 0. 0. 0.
     0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 0. 1. 1. 0. 1. 1. 1. 1. 1.
     0. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 0. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0.]
    Tuned K_NearestNeighbors Parameters: {'leaf_size': 1, 'n_neighbors': 7, 'p': 1}
    Best score is 0.7565625
    Confusion Matrix:  [[324  76]
     [ 88 312]]
    Accuracy Score:  0.795
    Score:  0.795
    
    SVM
    y_pred:  [1. 0. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1.
     0. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 0. 0. 0. 0.
     1. 0. 1. 1. 0. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1.
     1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 0. 0. 0. 0.
     0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0.
     0. 0. 1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 0. 0. 0. 0. 1. 0. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 0. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 0. 1. 0. 1. 0. 0. 0. 0.
     0. 1. 1. 0. 0. 0. 0. 0. 1. 1. 0. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 0. 0. 0. 0. 1. 1. 0. 0. 1. 1. 1. 1.
     1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1.
     0. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 0. 0. 0. 0.
     1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0.
     1. 1. 0. 1. 1. 1. 1. 1.]
    Tuned SVM Parameters: {'C': 100, 'gamma': 'auto'}
    Best score is 0.7670833333333333
    Confusion Matrix:  [[228 172]
     [116 284]]
    Accuracy Score:  0.64
    Score:  0.64
    
    RFC


    /opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/model_selection/_validation.py:378: FitFailedWarning: 
    75 fits failed out of a total of 300.
    The score on these train-test partitions for these parameters will be set to nan.
    If these failures are not expected, you can try to debug them by setting error_score='raise'.
    
    Below are more details about the failures:
    --------------------------------------------------------------------------------
    75 fits failed with the following error:
    Traceback (most recent call last):
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/model_selection/_validation.py", line 686, in _fit_and_score
        estimator.fit(X_train, y_train, **fit_params)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/ensemble/_forest.py", line 476, in fit
        trees = Parallel(
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/joblib/parallel.py", line 1043, in __call__
        if self.dispatch_one_batch(iterator):
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/joblib/parallel.py", line 861, in dispatch_one_batch
        self._dispatch(tasks)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/joblib/parallel.py", line 779, in _dispatch
        job = self._backend.apply_async(batch, callback=cb)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/joblib/_parallel_backends.py", line 208, in apply_async
        result = ImmediateResult(func)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/joblib/_parallel_backends.py", line 572, in __init__
        self.results = batch()
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/joblib/parallel.py", line 262, in __call__
        return [func(*args, **kwargs)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/joblib/parallel.py", line 262, in <listcomp>
        return [func(*args, **kwargs)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/utils/fixes.py", line 117, in __call__
        return self.function(*args, **kwargs)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/ensemble/_forest.py", line 189, in _parallel_build_trees
        tree.fit(X, y, sample_weight=curr_sample_weight, check_input=False)
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/tree/_classes.py", line 969, in fit
        super().fit(
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/tree/_classes.py", line 265, in fit
        check_scalar(
      File "/opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/utils/validation.py", line 1480, in check_scalar
        raise ValueError(
    ValueError: min_samples_split == 0, must be >= 2.
    
      warnings.warn(some_fits_failed_message, FitFailedWarning)
    /opt/jupyterhub/anaconda/lib/python3.9/site-packages/sklearn/model_selection/_search.py:953: UserWarning: One or more of the test scores are non-finite: [       nan        nan        nan 0.71885417 0.66364583 0.628125
     0.71989583 0.65364583 0.61989583 0.71625    0.64947917 0.63270833
            nan        nan        nan 0.71802083 0.65302083 0.628125
     0.7209375  0.66041667 0.61989583 0.718125   0.66083333 0.62333333
            nan        nan        nan 0.72020833 0.65697917 0.62666667
     0.7196875  0.65666667 0.63395833 0.71645833 0.654375   0.63354167
            nan        nan        nan 0.71947917 0.65541667 0.62145833
     0.72197917 0.66822917 0.6203125  0.7134375  0.65572917 0.62979167
            nan        nan        nan 0.71645833 0.6565625  0.63
     0.72208333 0.6603125  0.62114583 0.71822917 0.65760417 0.61958333]
      warnings.warn(


    y_pred:  [1. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 1. 1. 1. 1.
     0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1.
     0. 1. 1. 0. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 0. 1. 0. 0. 0. 0.
     0. 0. 0. 1. 0. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 1. 0. 0. 0. 0.
     0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 0. 1. 1. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0. 0. 0.
     1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 0. 0. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 0. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 0.
     1. 0. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 0.
     0. 1. 0. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 0. 0. 0. 1. 1. 1. 1. 1. 0. 0. 1. 1. 1. 1. 1. 0. 1. 0. 0. 1. 1. 1. 1.
     0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 0. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 0. 1. 0. 0. 0. 0. 1. 1. 0. 0. 1. 1. 1. 1.
     0. 1. 0. 0. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 0. 0. 0. 0. 0. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0.
     1. 1. 0. 1. 1. 1. 1. 1.]
    Tuned RFC Parameters: {'min_samples_leaf': 10, 'min_samples_split': 10, 'min_weight_fraction_leaf': 0.01}
    Best score is 0.7220833333333333
    Confusion Matrix:  [[208 192]
     [135 265]]
    Accuracy Score:  0.59125
    Score:  0.59125
    ====================================================================



```python
# parameters = 10
# for i in range(1, parameters):
#     print("i ", i)
#     model = KNeighborsClassifier(n_neighbors = i)
#     model.fit(X_train, y_train)
#     y_pred = model.predict(TotalValidateMatrix)
#     #print(y_pred)
#     print(recall_score(y_validate, y_pred))
#     print(confusion_matrix(y_true = y_validate, y_pred = y_pred))
#     print(accuracy_score(y_validate, y_pred))
#     print("====================")
```


```python
testClassifier = KNeighborsClassifier(leaf_size= 1, n_neighbors= 7, p= 1)
testClassifier.fit(X_train, y_train)
testYpred = testClassifier.predict(TotalTestMatrix)

print("y_pred: ", testYpred)
print("Confusion Matrix: ", confusion_matrix(y_true = y_test, y_pred = testYpred))
#print("Classification Report: ", classification_report(y_test, testYpred))
print("Accuracy Score: ", accuracy_score(y_test, testYpred))
```

    y_pred:  [1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 0. 1. 1. 0. 0. 0. 0.
     0. 1. 0. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 1. 1. 1. 1.
     1. 0. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 1. 1. 1. 1.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0.
     1. 0. 0. 1. 0. 0. 0. 0. 1. 0. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 0. 0. 1. 1. 1. 1. 1. 1. 0. 1. 0. 1. 1. 1. 1. 0. 0. 0. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0.
     0. 0. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0. 0.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1.
     0. 1. 1. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 0. 0. 1. 0. 0. 0. 0. 0.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0.]
    Confusion Matrix:  [[312  88]
     [ 79 321]]
    Accuracy Score:  0.79125



```python
# Import Required libraries
import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import load_digits
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import validation_curve


# Setting the range for the parameter (from 1 to 10)
parameter_range = np.arange(5, 8, 1)

# Calculate accuracy on training and test set using the
# gamma parameter with 5-fold cross validation
train_score, test_score = validation_curve(KNeighborsClassifier(leaf_size= 1, p= 1), X_train, y_train,
									param_name = "n_neighbors",
									param_range = parameter_range,
										cv = 5, scoring = "accuracy")

# Calculating mean and standard deviation of training score
mean_train_score = np.mean(train_score, axis = 1)
std_train_score = np.std(train_score, axis = 1)

# Calculating mean and standard deviation of testing score
mean_test_score = np.mean(test_score, axis = 1)
std_test_score = np.std(test_score, axis = 1)

# Plot mean accuracy scores for training and testing scores
plt.plot(parameter_range, mean_train_score,
	label = "Training Score", color = 'b')
plt.plot(parameter_range, mean_test_score,
label = "Test score", color = 'g')

# Creating the plot
plt.title("Validation Curve with KNN Classifier")
plt.xlabel("Number of Neighbours")
plt.ylabel("Accuracy")
plt.tight_layout()
plt.legend(loc = 'best')
plt.show()

```


    
![png](output_28_0.png)
    



```python
# testClassifier = SVC(C= 100, gamma= 'auto')
# testClassifier.fit(X_train, y_train)
# testYpred = testClassifier.predict(TotalTestMatrix)

# print("y_pred: ", testYpred)
# print("Confusion Matrix: ", confusion_matrix(y_true = y_test, y_pred = testYpred))
# #print("Classification Report: ", classification_report(y_test, testYpred))
# print("Accuracy Score: ", accuracy_score(y_test, testYpred))
```

    y_pred:  [0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 0. 1. 0. 0. 0. 0. 1. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     0. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 0. 0. 1. 1. 1. 1.
     1. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 0. 1. 1. 1. 1.
     1. 1. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 0. 1. 1. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0. 0.
     1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 0. 0.
     0. 0. 1. 0. 1. 1. 1. 1. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0.
     0. 1. 0. 1. 0. 0. 0. 0. 0. 1. 0. 1. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 1. 0. 0. 1. 1. 1. 1.
     1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0. 0.
     1. 0. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 0. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1.
     0. 1. 1. 0. 1. 1. 1. 1. 1. 0. 0. 1. 0. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0.
     1. 0. 0. 0. 0. 0. 0. 0. 1. 0. 1. 0. 1. 1. 1. 1. 1. 1. 1. 1. 0. 0. 0. 0.
     0. 1. 1. 1. 0. 0. 0. 0. 0. 0. 1. 0. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0.
     1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1.
     1. 1. 1. 1. 0. 0. 0. 0.]
    Confusion Matrix:  [[232 168]
     [ 88 312]]
    Accuracy Score:  0.68



```python

```
